﻿using System.Linq;
using WarehouseData.Models;
using WarehouseData.Services;
using Xunit;

namespace Warehouse_Tests_xUnit
{
    public class UnitTest1
    {
        private DataService dataService;

        public UnitTest1()
        {
            dataService = new DataService();
            SeedTestData();
        }

        private void SeedTestData()
        {
            if (!dataService.Organizations.Any())
                dataService.Organizations.Add(new Organization(1, "Тестовая организация"));

            if (!dataService.Warehouses.Any())
                dataService.Warehouses.Add(new Warehouse(1, 1, "Склад 1", "Адрес 1"));

            if (!dataService.Products.Any())
                dataService.Products.Add(new Product
                {
                    Id = 1,
                    WarehouseId = 1,
                    Name = "Товар 1",
                    Category = "Категория 1",
                    Manufacturer = "Производитель 1",
                    Supplier = "Поставщик 1",
                    Price = 100,
                    StockQuantity = 10,
                    DiscountPercent = 0
                });
        }

        [Fact]
        public void AddOrganization_ShouldIncreaseCount()
        {
            int initialCount = dataService.Organizations.Count;

            dataService.Organizations.Add(new Organization(999, "Тестовая организация 2"));

            Assert.Equal(initialCount + 1, dataService.Organizations.Count);
        }

        [Fact]
        public void AddWarehouse_ShouldAssignCorrectOrganizationId()
        {
            var org = dataService.Organizations.First();
            int initialCount = dataService.Warehouses.Count;

            var warehouse = new Warehouse(999, org.Id, "Тестовый склад", "Тестовый адрес");
            dataService.Warehouses.Add(warehouse);

            Assert.Equal(initialCount + 1, dataService.Warehouses.Count);
            Assert.Equal(org.Id, warehouse.OrganizationId);
        }

        [Fact]
        public void AddProduct_ShouldAssignCorrectWarehouseId()
        {
            var warehouse = dataService.Warehouses.First();
            int initialCount = dataService.Products.Count;

            var product = new Product
            {
                Id = 999,
                WarehouseId = warehouse.Id,
                Name = "Тестовый товар",
                Category = "Тест",
                Manufacturer = "ТестПроизв",
                Supplier = "ТестПоставщик",
                Price = 100,
                StockQuantity = 10,
                DiscountPercent = 0
            };

            dataService.Products.Add(product);

            Assert.Equal(initialCount + 1, dataService.Products.Count);
            Assert.Equal(warehouse.Id, product.WarehouseId);
        }

        [Fact]
        public void DeleteWarehouse_ShouldRemoveAssociatedProducts()
        {
            var warehouse = dataService.Warehouses.First();
            var productsInWarehouse = dataService.Products
                .Where(p => p.WarehouseId == warehouse.Id).ToList();

            foreach (var p in productsInWarehouse)
                dataService.Products.Remove(p);

            dataService.Warehouses.Remove(warehouse);

            foreach (var p in productsInWarehouse)
                Assert.DoesNotContain(p, dataService.Products);

            Assert.DoesNotContain(warehouse, dataService.Warehouses);
        }

        [Fact]
        public void Invoice_Incoming_ShouldIncreaseStock()
        {
            var warehouse = dataService.Warehouses.First();
            var product = dataService.Products.First(p => p.WarehouseId == warehouse.Id);
            int oldStock = product.StockQuantity;

            int quantity = 5;


            product.StockQuantity += quantity;

            Assert.Equal(oldStock + quantity, product.StockQuantity);
        }

        [Fact]
        public void Invoice_Outgoing_ShouldDecreaseStock()
        {
            var warehouse = dataService.Warehouses.First();
            var product = dataService.Products.First(p => p.WarehouseId == warehouse.Id);
            int oldStock = product.StockQuantity;

            int quantity = 3;
            if (oldStock >= quantity)
                product.StockQuantity -= quantity;

            Assert.Equal(oldStock - quantity, product.StockQuantity);
        }
    }
}